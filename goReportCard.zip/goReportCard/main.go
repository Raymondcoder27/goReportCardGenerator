package main

import (
	// "bufio"
	// "fmt"
	// "os"
	// "strconv"
	// "strings"

	"github.com/gin-gonic/gin"
	"github.com/jung-kurt.com/controllers"
	// "github.com/jung-kurt.com/controllers"
)

func main() {
	r := gin.Default()

	r.POST("/createReport", controllers.CreateReport)
	// r.GET("/", func(c *gin.Context) {
	// 	c.JSON(200, gin.H{
	// 		"message": "This is where you will see the report",
	// 	})
	// })

	r.Run()
}
