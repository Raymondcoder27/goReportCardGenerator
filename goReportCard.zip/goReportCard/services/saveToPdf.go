package reports

import (
	"fmt"
	"strings"

	"github.com/jung-kurt/gofpdf"
)

type Report struct {
	StudentName string
	Class       string
	Marks       map[string]int
	Comment     string
}

// Format the report as a string
func (r *Report) format() string {
	fs := fmt.Sprintf("REPORT CARD\nStudent: %s\nClass: %s\n\n", r.StudentName, r.Class)
	totalMarks := 0

	for subject, mark := range r.Marks {
		fs += fmt.Sprintf("%-25v  %d\n", subject+":", mark)
		totalMarks += mark
	}

	fs += fmt.Sprintf("\n%-25v %d\n", "Total Marks:", totalMarks)
	fs += fmt.Sprintf("%-25v %v", "Teacher's comment:", r.Comment)

	return fs
}

// Save the report to a PDF
func SaveToPdf(r *Report) error {
	pdf := gofpdf.New("P", "mm", "A4", "")
	pdf.AddPage()
	pdf.SetFont("Courier", "", 14)

	lines := strings.Split(r.format(), "\n")

	for _, line := range lines {
		pdf.CellFormat(0, 10, line, "", 1, "C", false, 0, "")
		pdf.Ln(10)
	}

	filename := fmt.Sprintf("generatedReports/%s.pdf", r.StudentName)
	err := pdf.OutputFileAndClose(filename)
	if err != nil {
		return err
	}
	fmt.Println("You saved the file to a PDF:", filename)
	return nil
}
