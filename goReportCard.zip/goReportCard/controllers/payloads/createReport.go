package payloads

type CreateReportPayload struct {
	Class       string            `json:"class"`
	StudentName string            `json:"student_name"`
	Marks       map[string]int    `json:"marks"`
	Comment     string            `json:"comment"`
}
