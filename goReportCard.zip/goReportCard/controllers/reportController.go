package controllers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/jung-kurt.com/controllers/payloads"
	reports "github.com/jung-kurt.com/services"
	// "github.com/jung-kurt.com/services/reports"
)

func CreateReport(c *gin.Context) {
	var body payloads.CreateReportPayload
	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	// body := &reports.Report{
	// 	StudentName: "Jack",
	// 	Class:       "P.7",
	// 	Marks: map[string]int{
	// 		"math":    90,
	// 		"english": 80,
	// 	},
	// 	Comment: "Well done",
	// }

	report := &reports.Report{
		StudentName: body.StudentName,
		Class:       body.Class,
		Marks:       body.Marks,
		Comment:     body.Comment,
	}

	// err := reports.SaveToPdf(body)
	err := reports.SaveToPdf(report)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// c.JSON(http.StatusCreated, body)
	c.JSON(http.StatusCreated, report)
}
